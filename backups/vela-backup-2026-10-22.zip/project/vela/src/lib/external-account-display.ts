/** Display-safe helpers for external accounts / counterparty text. */
import { BRAND } from "@/lib/brand";

export function lastFourDigits(value: string | null | undefined): string {
  const digits = String(value ?? "").replace(/\D/g, "");
  return digits.slice(-4);
}

export function containsLongAccountLikeNumber(value: string | null | undefined): boolean {
  return /\d{7,}/.test(String(value ?? "").replace(/[\s-]/g, ""));
}

function replaceLegacyBrand(value: string): string {
  return value
    .replace(/First Meridian\s+Bank/gi, "FMB")
    .replace(/First Meridian\s+debit\s+card/gi, "FMB debit card")
    .replace(/First Meridian/gi, "FMB");
}

function clean(value: string | null | undefined, fallback: string, max = 60): string {
  const text = replaceLegacyBrand(String(value ?? "")).replace(/\s+/g, " ").trim();
  if (!text || containsLongAccountLikeNumber(text)) return fallback;
  return text.slice(0, max);
}

export function safeInstitutionName(value: string | null | undefined): string {
  return clean(value, "External bank");
}

/** A human-entered payment originator shown as the transaction description. */
export function safeSenderName(value: string | null | undefined): string {
  return clean(value, "Unknown sender", 65);
}

export function safeExternalNickname(value: string | null | undefined, accountType?: string | null): string {
  return clean(value, accountType === "SAVINGS" ? "External savings" : "External checking");
}

export function safeCounterparty(value: string | null | undefined): string | null {
  if (!value) return null;
  return clean(value, "FMB", 90);
}

export function safeTransactionDescription(value: string | null | undefined): string {
  return clean(value, "Account activity", 90);
}

export function isAdminCreditReference(reference: string | null | undefined): boolean {
  return /^admin(?:ach|wire)_/i.test(String(reference ?? ""));
}

const METHOD_LABELS: Record<string, string> = {
  ACH: "ACH",
  WIRE: "Wire",
  BILL_PAY: "Bill Pay",
  INTERNAL: "Internal",
  QUICK_PAY: "Quick Pay",
  MOBILE_DEPOSIT: "Mobile Deposit",
};

export function paymentMethodLabel(method: string | null | undefined): string | null {
  if (!method) return null;
  return METHOD_LABELS[method] ?? null;
}
