# Vela project backup

Created: 2026-10-22 (Africa/Lagos)

- `project/` is a snapshot of the current working tree, including the project files, assets, tests, and tracked `vela/prisma/dev.db` data.
- `git/repository.bundle` contains all Git refs and history available in the checkout.
- `git/working-tree.patch` records the uncommitted tracked changes present at backup time; the exact changed files are also included in `project/`.
- `git/status-at-backup.txt`, `git/branch.txt`, and `git/head.txt` record repository state.
- `node_modules`, `.next`, local `.env` files, and disposable unit/E2E databases are excluded because they are regenerable, sensitive, or temporary. No local `.env` files were present when this backup was made.

The source checkout is shallow, so the bundle preserves the history available locally rather than commits absent from the checkout. The Git bundle does not include local `.git/config` or credentials.

To restore the working files, extract `project/`. To restore the available Git history, clone `git/repository.bundle`, then apply `git/working-tree.patch` if you want the edits represented as a diff on top of the bundled HEAD.
