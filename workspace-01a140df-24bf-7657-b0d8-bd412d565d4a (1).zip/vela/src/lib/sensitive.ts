import "server-only";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";

/**
 * Encrypt provider tokens and account identifiers at rest. In production, set
 * APP_ENCRYPTION_KEY to a dedicated base64-encoded 32-byte key. The AUTH_SECRET
 * fallback is intentionally development-only so a fresh demo still runs.
 */
function encryptionKey() {
  const configured = process.env.APP_ENCRYPTION_KEY;
  if (configured) {
    const key = Buffer.from(configured, "base64");
    if (key.length !== 32) throw new Error("APP_ENCRYPTION_KEY must be a base64-encoded 32-byte key");
    return key;
  }
  if (process.env.NODE_ENV === "production") {
    throw new Error("APP_ENCRYPTION_KEY must be configured in production");
  }
  const fallback = process.env.AUTH_SECRET;
  if (!fallback) throw new Error("Set APP_ENCRYPTION_KEY before storing sensitive data");
  return createHash("sha256").update(fallback).digest();
}

export function encryptSensitive(plaintext: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64url")}:${tag.toString("base64url")}:${ciphertext.toString("base64url")}`;
}

export function decryptSensitive(encoded: string) {
  const [version, ivText, tagText, ciphertextText] = encoded.split(":");
  if (version !== "v1" || !ivText || !tagText || !ciphertextText) {
    throw new Error("Unsupported encrypted value");
  }
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivText, "base64url"));
  decipher.setAuthTag(Buffer.from(tagText, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertextText, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}
