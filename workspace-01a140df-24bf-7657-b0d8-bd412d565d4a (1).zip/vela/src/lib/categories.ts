import type { LucideIcon } from "lucide-react";
import {
  ArrowLeftRight,
  Car,
  Film,
  HeartPulse,
  Home,
  PiggyBank,
  Shapes,
  ShoppingBag,
  UtensilsCrossed,
  Zap,
  TrendingUp,
} from "lucide-react";

/** Institutional palette: navy, red, teal, ochre, muted violets. */
export const CATEGORY_META: Record<
  string,
  { label: string; color: string; icon: LucideIcon }
> = {
  INCOME: { label: "Income", color: "#2E7D32", icon: TrendingUp },
  HOUSING: { label: "Housing", color: "#002855", icon: Home },
  FOOD: { label: "Food & dining", color: "#B26A00", icon: UtensilsCrossed },
  TRANSPORT: { label: "Transportation", color: "#0057B8", icon: Car },
  SHOPPING: { label: "Shopping", color: "#6A3FA0", icon: ShoppingBag },
  ENTERTAINMENT: { label: "Entertainment", color: "#A62B6B", icon: Film },
  UTILITIES: { label: "Utilities", color: "#00796B", icon: Zap },
  HEALTH: { label: "Health", color: "#C62828", icon: HeartPulse },
  TRANSFER: { label: "Transfers", color: "#5A6472", icon: ArrowLeftRight },
  SAVINGS: { label: "Savings", color: "#00695C", icon: PiggyBank },
  OTHER: { label: "Other", color: "#8A919B", icon: Shapes },
};

export function categoryMeta(category: string) {
  return CATEGORY_META[category] ?? CATEGORY_META.OTHER;
}
