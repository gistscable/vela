import "server-only";

export function stripeKeyStatus() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return { configured: false, mode: "demo" as const, problem: null };
  if (!key.startsWith("sk_test_")) {
    return {
      configured: false,
      mode: "disabled" as const,
      problem: "Stripe test keys are required. Live money movement is disabled.",
    };
  }
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    return {
      configured: false,
      mode: "test" as const,
      problem: "Add STRIPE_WEBHOOK_SECRET so signed Stripe test events can create pending deposit requests.",
    };
  }
  return { configured: true, mode: "test" as const, problem: null };
}

/** Load Stripe only in the Checkout action or webhook; it is not part of every page bundle. */
export async function getStripeClient() {
  const status = stripeKeyStatus();
  if (!status.configured) return null;
  const Stripe = (await import("stripe")).default;
  return new Stripe(process.env.STRIPE_SECRET_KEY!);
}
