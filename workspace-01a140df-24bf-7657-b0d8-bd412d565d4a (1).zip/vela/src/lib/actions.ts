"use server";

import { revalidatePath } from "next/cache";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "./db";
import {
  clearSessionCookie,
  getEffectiveUserId,
  hashPassword,
  isSharedPreviewDemoMode,
  requireMfaChallengeUser,
  setMfaChallengeCookie,
  setSessionCookie,
  verifyPassword,
} from "./auth";
import { parseCents } from "./money";
import { containsLongAccountLikeNumber, lastFourDigits, safeExternalNickname, safeInstitutionName } from "./external-account-display";
import { decryptSensitive, encryptSensitive } from "./sensitive";
import { generateTotpSecret, matchingTotpStep } from "./totp";
import { getStripeClient, stripeKeyStatus } from "./stripe";

export type ActionState = { error?: string; success?: boolean; message?: string; confirmation?: string } | null;

const emailSchema = z.string().trim().toLowerCase().email("Enter a valid email address");
const passwordSchema = z.string().min(8, "Password must be at least 8 characters").max(200);

function accountNumber() {
  // 12-digit fake account number, never starts with 0
  let n = "";
  for (let i = 0; i < 12; i++) n += Math.floor(Math.random() * 10);
  return n.startsWith("0") ? `7${n.slice(1)}` : n;
}

function routingNumber() {
  return "021000021"; // demo routing (JPMorgan Chase test number)
}

function randomRef(prefix: string) {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

/* ------------------------------ AUTH ------------------------------ */

export async function signupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (await isSharedPreviewDemoMode()) redirect("/dashboard");

  const parsed = z
    .object({
      firstName: z.string().trim().min(1, "First name is required").max(50),
      lastName: z.string().trim().min(1, "Last name is required").max(50),
      email: emailSchema,
      password: passwordSchema,
    })
    .safeParse({
      firstName: formData.get("firstName"),
      lastName: formData.get("lastName"),
      email: formData.get("email"),
      password: formData.get("password"),
    });

  if (!parsed.success) {
    return { error: parsed.error.errors[0]?.message ?? "Invalid input" };
  }
  const { firstName, lastName, email, password } = parsed.data;
  if (formData.get("ageConfirmed") !== "yes") {
    return { error: "You must confirm that you are at least 18 to continue." };
  }
  if (formData.get("usResident") !== "yes") {
    return { error: "This prototype enrollment is limited to people who confirm U.S. residency." };
  }
  if (!["ACCOUNT", "CARD"].includes(String(formData.get("identifierType") ?? ""))) {
    return { error: "Choose an account or card for the demo identification step." };
  }
  if (!/^\d{6}$/.test(String(formData.get("lastSix") ?? ""))) {
    return { error: "Enter six demo digits for the identification step." };
  }
  if (formData.get("alternateVerification") !== "yes") {
    return { error: "Select the alternate demo verification option. SSN and TIN are not collected." };
  }

  // lastSix is only validated to demonstrate the form. It is deliberately not
  // assigned to the user, logged, or persisted in any table.
  const existing = await db.user.findUnique({ where: { email } });
  if (existing) return { error: "An account with this email already exists. Try logging in." };

  const passwordHash = await hashPassword(password);
  const openingRaw = formData.get("openingDeposit");
  const openingCents = typeof openingRaw === "string" && openingRaw.trim() !== "" ? parseCents(openingRaw) : 0;
  if (openingCents === null || openingCents < 0) return { error: "Enter a valid opening deposit" };

  await db.user.create({
    data: {
      email,
      enrollmentStatus: "PENDING_APPROVAL",
      passwordHash,
      firstName,
      lastName,
      phone: typeof formData.get("phone") === "string" && formData.get("phone") ? (formData.get("phone") as string) : null,
      accounts: {
        create: [
          {
            type: "CHECKING",
            name: "Everyday Checking",
            accountNumber: accountNumber(),
            routingNumber: routingNumber(),
            balance: 0,
            cards: {
              create: { last4: String(Math.floor(1000 + Math.random() * 9000)), brand: "Visa" },
            },
            transactions:
              openingCents && openingCents > 0
                ? {
                    create: {
                      amount: openingCents,
                      type: "DEPOSIT",
                      category: "TRANSFER",
                      description: "Opening deposit",
                      counterparty: "External bank · •••• 1234",
                      status: "PENDING_APPROVAL",
                      reference: randomRef("opening"),
                    },
                  }
                : undefined,
          },
          {
            type: "SAVINGS",
            name: "High-Yield Savings",
            accountNumber: accountNumber(),
            routingNumber: routingNumber(),
            balance: 0,
            apy: 4.25,
          },
        ],
      },
    },
  });

  revalidatePath("/admin");
  revalidatePath("/", "layout");
  redirect("/enrollment/pending");
}

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (await isSharedPreviewDemoMode()) redirect("/dashboard");

  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) return { error: "Email and password are required" };

  const user = await db.user.findUnique({ where: { email } });
  if (!user) return { error: "Invalid email or password" };

  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return { error: "Invalid email or password" };
  if (user.enrollmentStatus === "PENDING_APPROVAL") {
    return { error: "Your enrollment is awaiting admin approval. You can sign in after it is approved." };
  }
  if (user.enrollmentStatus !== "APPROVED") {
    return { error: "This enrollment was not approved. Please contact support." };
  }

  const now = new Date();
  if (user.mfaEnabled) {
    if (!user.totpSecretEncrypted) {
      return { error: "Your authenticator is not configured. Contact an administrator to reset it." };
    }
    await setMfaChallengeCookie(user.id, "verify");
    redirect("/mfa/verify");
  }

  const pendingSecretActive = Boolean(
    user.mfaPendingSecretEncrypted && user.mfaPendingExpiresAt && user.mfaPendingExpiresAt > now,
  );
  if (!pendingSecretActive) {
    const secret = generateTotpSecret();
    await db.user.update({
      where: { id: user.id },
      data: {
        mfaPendingSecretEncrypted: encryptSensitive(secret),
        mfaPendingExpiresAt: new Date(now.getTime() + 10 * 60 * 1000),
        mfaFailedAttempts: 0,
        mfaLockedUntil: null,
      },
    });
  }
  await setMfaChallengeCookie(user.id, "setup");
  redirect("/mfa/setup");
}

async function registerMfaFailure(user: {
  id: string;
  mfaFailedAttempts: number;
  mfaLockedUntil: Date | null;
}) {
  const attemptCount = user.mfaFailedAttempts + 1;
  const lockUntil = attemptCount >= 5 ? new Date(Date.now() + 5 * 60 * 1000) : null;
  const update = await db.user.updateMany({
    where: {
      id: user.id,
      enrollmentStatus: "APPROVED",
      mfaFailedAttempts: user.mfaFailedAttempts,
      mfaLockedUntil: user.mfaLockedUntil,
    },
    data: { mfaFailedAttempts: attemptCount, mfaLockedUntil: lockUntil },
  });
  return { updated: update.count === 1, attemptCount };
}

function mfaLockedError() {
  return "Too many incorrect codes. Wait five minutes, then try again.";
}

export async function completeTotpSetupAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireMfaChallengeUser("setup");
  const code = String(formData.get("totpCode") ?? "").trim();
  const now = new Date();
  if (user.mfaLockedUntil && user.mfaLockedUntil > now) return { error: mfaLockedError() };
  if (!user.mfaPendingSecretEncrypted || !user.mfaPendingExpiresAt || user.mfaPendingExpiresAt <= now) {
    return { error: "This setup has expired. Sign in again to start a new authenticator setup." };
  }

  let secret: string;
  try {
    secret = decryptSensitive(user.mfaPendingSecretEncrypted);
  } catch {
    return { error: "Could not read the pending authenticator setup. Contact an administrator." };
  }
  const step = matchingTotpStep(secret, code);
  if (step === null) {
    const failure = await registerMfaFailure(user);
    if (!failure.updated) return { error: "The setup changed. Refresh the page and try again." };
    return { error: failure.attemptCount >= 5 ? mfaLockedError() : `That code did not match. ${5 - failure.attemptCount} attempt${5 - failure.attemptCount === 1 ? "" : "s"} remaining.` };
  }

  const activated = await db.user.updateMany({
    where: {
      id: user.id,
      enrollmentStatus: "APPROVED",
      mfaEnabled: false,
      mfaPendingSecretEncrypted: user.mfaPendingSecretEncrypted,
      mfaPendingExpiresAt: user.mfaPendingExpiresAt,
      mfaFailedAttempts: user.mfaFailedAttempts,
      mfaLockedUntil: user.mfaLockedUntil,
    },
    data: {
      mfaEnabled: true,
      totpSecretEncrypted: user.mfaPendingSecretEncrypted,
      totpLastUsedStep: step,
      mfaPendingSecretEncrypted: null,
      mfaPendingExpiresAt: null,
      mfaFailedAttempts: 0,
      mfaLockedUntil: null,
    },
  });
  if (activated.count !== 1) return { error: "The setup changed. Refresh the page and try again." };
  await setSessionCookie(user.id);
  revalidatePath("/", "layout");
  redirect("/dashboard");
}

export async function verifyTotpLoginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const user = await requireMfaChallengeUser("verify");
  const code = String(formData.get("totpCode") ?? "").trim();
  const now = new Date();
  if (user.mfaLockedUntil && user.mfaLockedUntil > now) return { error: mfaLockedError() };
  if (!user.totpSecretEncrypted) return { error: "Your authenticator is not configured. Contact an administrator." };

  let secret: string;
  try {
    secret = decryptSensitive(user.totpSecretEncrypted);
  } catch {
    return { error: "Could not verify your authenticator. Contact an administrator." };
  }
  const step = matchingTotpStep(secret, code);
  if (step === null || (user.totpLastUsedStep !== null && step <= user.totpLastUsedStep)) {
    const failure = await registerMfaFailure(user);
    if (!failure.updated) return { error: "The sign-in challenge changed. Refresh the page and try again." };
    return { error: failure.attemptCount >= 5 ? mfaLockedError() : `That code did not work. ${5 - failure.attemptCount} attempt${5 - failure.attemptCount === 1 ? "" : "s"} remaining.` };
  }

  const lastUsedFilter = user.totpLastUsedStep === null
    ? { totpLastUsedStep: null }
    : { totpLastUsedStep: { lt: step } };
  const verified = await db.user.updateMany({
    where: {
      id: user.id,
      enrollmentStatus: "APPROVED",
      mfaEnabled: true,
      totpSecretEncrypted: user.totpSecretEncrypted,
      mfaFailedAttempts: user.mfaFailedAttempts,
      mfaLockedUntil: user.mfaLockedUntil,
      ...lastUsedFilter,
    },
    data: { totpLastUsedStep: step, mfaFailedAttempts: 0, mfaLockedUntil: null },
  });
  if (verified.count !== 1) return { error: "That code was already used or the challenge changed. Enter the newest code." };

  await setSessionCookie(user.id);
  revalidatePath("/", "layout");
  redirect("/dashboard");
}

export async function logoutAction() {
  if (await isSharedPreviewDemoMode()) redirect("/dashboard");
  await clearSessionCookie();
  revalidatePath("/", "layout");
  redirect("/login");
}

/* ---------------------------- MONEY MOVEMENT ---------------------------- */

async function requireUserId() {
  const userId = await getEffectiveUserId();
  if (!userId) redirect("/login");
  return userId;
}

export async function addExternalAccountAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const parsed = z
    .object({
      institutionName: z.string().trim().min(2, "Enter a bank or credit union name").max(80).refine((value) => !containsLongAccountLikeNumber(value), "Do not enter an account or routing number here. Use a bank name only."),
      nickname: z.string().trim().min(2, "Enter an account nickname").max(60).refine((value) => !containsLongAccountLikeNumber(value), "Do not enter an account or routing number here. Use a nickname only."),
      accountType: z.enum(["CHECKING", "SAVINGS"]),
      accountNumber: z.string().trim().regex(/^\d{4,17}$/, "Enter a 4–17 digit account number."),
      routingNumber: z.string().trim().regex(/^\d{9}$/, "Enter a 9-digit routing number."),
    })
    .safeParse({
      institutionName: formData.get("institutionName"),
      nickname: formData.get("nickname"),
      accountType: formData.get("accountType"),
      accountNumber: formData.get("accountNumber"),
      routingNumber: formData.get("routingNumber"),
    });

  if (!parsed.success) return { error: parsed.error.errors[0]?.message ?? "Check the account details" };
  const count = await db.externalAccount.count({ where: { userId } });
  if (count >= 5) return { error: "You can save up to five external accounts." };
  const duplicate = await db.externalAccount.findFirst({
    where: {
      userId,
      institutionName: parsed.data.institutionName,
      nickname: parsed.data.nickname,
      accountMask: lastFourDigits(parsed.data.accountNumber),
    },
  });
  if (duplicate) return { error: "That external account is already on your profile" };

  await db.externalAccount.create({
    data: {
      userId,
      institutionName: parsed.data.institutionName,
      nickname: parsed.data.nickname,
      accountType: parsed.data.accountType,
      accountMask: lastFourDigits(parsed.data.accountNumber),
      status: "PENDING_APPROVAL",
    },
  });
  revalidatePath("/linked-accounts");
  revalidatePath("/transfer");
  revalidatePath("/admin");
  return {
    success: true,
    message: `${parsed.data.nickname} was submitted for review. It can be used after admin review and microdeposit verification.`,
  };
}

export async function verifyExternalAccountAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const accountId = String(formData.get("externalAccountId") ?? "");
  const amount1 = parseCents(String(formData.get("microdepositAmount1") ?? ""));
  const amount2 = parseCents(String(formData.get("microdepositAmount2") ?? ""));
  if (!amount1 || !amount2 || amount1 < 1 || amount2 < 1 || amount1 > 99 || amount2 > 99 || amount1 === amount2) {
    return { error: "Enter the two different deposit amounts, each between $0.01 and $0.99." };
  }

  const destination = await db.externalAccount.findFirst({
    where: { id: accountId, userId, status: "CHALLENGE_ACTIVE" },
  });
  if (!destination || destination.microdepositAmount1 === null || destination.microdepositAmount2 === null) {
    return { error: "This destination is not ready for verification." };
  }

  const now = new Date();
  if (destination.microdepositExpiresAt && destination.microdepositExpiresAt < now) {
    const expired = await db.externalAccount.updateMany({
      where: {
        id: destination.id,
        userId,
        status: "CHALLENGE_ACTIVE",
        microdepositAmount1: destination.microdepositAmount1,
        microdepositAmount2: destination.microdepositAmount2,
        microdepositExpiresAt: destination.microdepositExpiresAt,
        microdepositAttempts: destination.microdepositAttempts,
      },
      data: {
        status: "PENDING_APPROVAL",
        microdepositAmount1: null,
        microdepositAmount2: null,
        microdepositExpiresAt: null,
        microdepositAttempts: 0,
      },
    });
    revalidatePath("/linked-accounts");
    revalidatePath("/admin");
    revalidatePath("/transfer");
    return expired.count === 1
      ? { error: "The verification window expired. This destination has been returned for admin review." }
      : { error: "This challenge changed. Refresh the page before trying again." };
  }

  if (amount1 !== destination.microdepositAmount1 || amount2 !== destination.microdepositAmount2) {
    const attempts = destination.microdepositAttempts + 1;
    const changed = await db.externalAccount.updateMany({
      where: {
        id: destination.id,
        userId,
        status: "CHALLENGE_ACTIVE",
        microdepositAmount1: destination.microdepositAmount1,
        microdepositAmount2: destination.microdepositAmount2,
        microdepositExpiresAt: destination.microdepositExpiresAt,
        microdepositAttempts: destination.microdepositAttempts,
      },
      data: attempts >= 5
        ? {
            status: "REJECTED",
            microdepositAmount1: null,
            microdepositAmount2: null,
            microdepositExpiresAt: null,
            microdepositAttempts: attempts,
          }
        : { microdepositAttempts: attempts },
    });
    revalidatePath("/linked-accounts");
    revalidatePath("/admin");
    if (changed.count !== 1) return { error: "This challenge changed. Refresh the page before trying again." };
    return {
      error: attempts >= 5
        ? "Verification was unsuccessful after five attempts. Contact support before trying again."
        : `Those amounts do not match. ${5 - attempts} attempt${5 - attempts === 1 ? "" : "s"} remaining.`,
    };
  }

  const verified = await db.externalAccount.updateMany({
    where: {
      id: destination.id,
      userId,
      status: "CHALLENGE_ACTIVE",
      microdepositAmount1: destination.microdepositAmount1,
      microdepositAmount2: destination.microdepositAmount2,
      microdepositExpiresAt: destination.microdepositExpiresAt,
      microdepositAttempts: destination.microdepositAttempts,
    },
    data: {
      status: "VERIFIED",
      microdepositAmount1: null,
      microdepositAmount2: null,
      microdepositExpiresAt: null,
      microdepositAttempts: 0,
      verifiedAt: now,
    },
  });
  revalidatePath("/linked-accounts");
  revalidatePath("/transfer");
  revalidatePath("/admin");
  if (verified.count !== 1) return { error: "This challenge changed. Refresh the page before trying again." };
  return { success: true, message: "External account passed the simulated challenge and is available for transfer requests." };
}

export async function depositAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const accountId = String(formData.get("accountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const source = String(formData.get("source") ?? "External bank · •••• 1234") || "External bank · •••• 1234";

  if (!amount || amount <= 0) return { error: "Enter an amount greater than $0" };
  if (amount > 1_000_000_00) return { error: "Deposits are limited to $1,000,000." };

  const account = await db.account.findFirst({ where: { id: accountId, userId } });
  if (!account) return { error: "Account not found" };
  if (account.status !== "ACTIVE") return { error: "This account is not active" };

  const transaction = await db.transaction.create({
    data: {
      accountId: account.id,
      amount,
      type: "DEPOSIT",
      category: "TRANSFER",
      description: "Deposit",
      counterparty: source,
      status: "PENDING_APPROVAL",
      reference: randomRef("dep"),
    },
  });

  revalidatePath("/dashboard");
  revalidatePath(`/accounts/${accountId}`);
  revalidatePath("/transactions");
  redirect(`/transactions/${transaction.id}`);
}

/** Mobile check capture records a request only; account balances change after approval. */
export async function mobileDepositAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const accountId = String(formData.get("accountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const checkNumber = String(formData.get("checkNumber") ?? "").trim();
  const frontSelected = formData.get("frontSelected") === "yes";
  const backSelected = formData.get("backSelected") === "yes";

  if (!frontSelected || !backSelected) return { error: "Add an image of both sides of the check." };
  if (!/^[a-zA-Z0-9-]{4,20}$/.test(checkNumber)) return { error: "Enter a check number between 4 and 20 letters or digits." };
  if (!amount || amount < 100) return { error: "Enter a deposit amount of at least $1.00." };
  if (amount > 500_000) return { error: "Mobile deposits are limited to $5,000.00." };

  const account = await db.account.findFirst({ where: { id: accountId, userId, status: "ACTIVE" } });
  if (!account) return { error: "Choose an active account you own." };

  const transaction = await db.transaction.create({
    data: {
      accountId: account.id,
      amount,
      type: "DEPOSIT",
      category: "TRANSFER",
      description: "Mobile check deposit",
      counterparty: `Check · •••• ${checkNumber.slice(-4)}`,
      paymentMethod: "MOBILE_DEPOSIT",
      status: "PENDING_APPROVAL",
      reference: randomRef("mobdep"),
    },
  });

  revalidatePath("/dashboard");
  revalidatePath(`/accounts/${accountId}`);
  revalidatePath("/transactions");
  redirect(`/transactions/${transaction.id}`);
}

export async function createStripeCheckoutAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (await isSharedPreviewDemoMode()) {
    return { error: "Stripe ACH test checkout is unavailable for the shared sample account. Use the internal deposit form instead." };
  }
  const userId = await requireUserId();
  const accountId = String(formData.get("accountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const stripeStatus = stripeKeyStatus();
  const stripe = await getStripeClient();

  if (!stripeStatus.configured || !stripe) {
    return { error: stripeStatus.problem ?? "Stripe test ACH is not configured." };
  }
  if (!amount || amount < 100) return { error: "Enter an amount of at least $1.00" };
  if (amount > 500_000) return { error: "Stripe test deposits are limited to $5,000.00" };

  const account = await db.account.findFirst({ where: { id: accountId, userId, status: "ACTIVE" } });
  if (!account) return { error: "Choose an active account you own" };

  const funding = await db.fundingIntent.create({
    data: {
      userId,
      accountId: account.id,
      amount,
      reference: randomRef("ach"),
      status: "CREATED",
      provider: "STRIPE",
    },
  });

  const requestHeaders = await headers();
  const origin = requestHeaders.get("origin") ?? "http://localhost:3000";
  const baseUrl = process.env.APP_BASE_URL || origin;
  let checkoutUrl: string | null = null;

  try {
    const metadata = { fundingIntentId: funding.id, userId, accountId: account.id };
    const session = await stripe.checkout.sessions.create(
      {
        mode: "payment",
        allowed_payment_method_types: ["us_bank_account"],
        payment_method_options: {
          us_bank_account: {
            financial_connections: { permissions: ["payment_method"], prefetch: [] },
          },
        },
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: { name: `Test ACH deposit — ${account.name}` },
              unit_amount: amount,
            },
            quantity: 1,
          },
        ],
        client_reference_id: funding.id,
        metadata,
        payment_intent_data: { metadata },
        success_url: `${baseUrl}/transfer?tab=deposit&checkout=returned&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${baseUrl}/transfer?tab=deposit&checkout=cancelled`,
      },
      { idempotencyKey: `funding_${funding.id}` },
    );
    checkoutUrl = session.url;
    await db.fundingIntent.update({
      where: { id: funding.id },
      data: { providerSessionId: session.id },
    });
  } catch (error) {
    console.error("Stripe test checkout setup failed", error);
    await db.fundingIntent.update({ where: { id: funding.id }, data: { status: "FAILED" } });
    return { error: "Secure Stripe checkout could not be started. Check your test-mode Stripe and webhook settings." };
  }

  if (!checkoutUrl) return { error: "Stripe did not return a checkout URL. Please try again." };
  redirect(checkoutUrl);
}

export async function withdrawAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const accountId = String(formData.get("accountId") ?? "");
  const externalAccountId = String(formData.get("externalAccountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const methodParsed = z.enum(["ACH", "WIRE"]).safeParse(String(formData.get("paymentMethod") ?? "ACH"));
  if (!methodParsed.success) return { error: "Choose ACH or wire transfer." };
  const paymentMethod = methodParsed.data;

  if (!amount || amount <= 0) return { error: "Enter an amount greater than $0" };
  if (amount > 10_000_000) return { error: "External transfers are limited to $100,000." };

  const [account, externalAccount] = await Promise.all([
    db.account.findFirst({ where: { id: accountId, userId } }),
    db.externalAccount.findFirst({ where: { id: externalAccountId, userId, status: "VERIFIED" } }),
  ]);
  if (!account) return { error: "Account not found" };
  if (!externalAccount) return { error: "Choose a saved external account first" };
  if (account.status !== "ACTIVE") return { error: "This account is not active" };
  if (account.balance < amount) return { error: "Insufficient funds for this withdrawal" };

  const destination = `${safeInstitutionName(externalAccount.institutionName)} · ${safeExternalNickname(externalAccount.nickname, externalAccount.accountType)} · •••• ${lastFourDigits(externalAccount.accountMask)}`;
  const transaction = await db.transaction.create({
    data: {
      accountId: account.id,
      amount: -amount,
      type: "WITHDRAWAL",
      category: "TRANSFER",
      description: "External transfer",
      counterparty: destination,
      paymentMethod,
      status: "PENDING_APPROVAL",
      reference: randomRef(paymentMethod === "ACH" ? "ach" : "wire"),
    },
  });

  revalidatePath("/dashboard");
  revalidatePath(`/accounts/${accountId}`);
  revalidatePath("/transactions");
  redirect(`/transactions/${transaction.id}`);
}

export async function transferAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const fromId = String(formData.get("fromId") ?? "");
  const toId = String(formData.get("toId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const memo = String(formData.get("memo") ?? "").trim().slice(0, 120) || "Transfer";

  if (!amount || amount < 100) return { error: "Enter an amount of at least $1.00" };
  if (amount > 10_000_000) return { error: "Transfers are limited to $100,000." };
  if (!fromId || !toId || fromId === toId) return { error: "Choose two different accounts" };

  const [from, to] = await Promise.all([
    db.account.findFirst({ where: { id: fromId, userId } }),
    db.account.findFirst({ where: { id: toId, userId } }),
  ]);
  if (!from || !to) return { error: "Account not found" };
  if (from.status !== "ACTIVE" || to.status !== "ACTIVE") return { error: "Both accounts must be active" };
  if (from.balance < amount) return { error: "Insufficient funds in the source account" };

  const reference = randomRef("trf");
  let transactionId = "";
  try {
    await db.$transaction(async (tx) => {
      const category = from.type === "SAVINGS" || to.type === "SAVINGS" ? "SAVINGS" : "TRANSFER";
      const debit = await tx.transaction.create({
        data: {
          accountId: from.id,
          amount: -amount,
          type: "TRANSFER_OUT",
          category,
          description: memo,
          counterparty: `To ${to.name}`,
          paymentMethod: "INTERNAL",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      await tx.transaction.create({
        data: {
          accountId: to.id,
          amount,
          type: "TRANSFER_IN",
          category,
          description: memo,
          counterparty: `From ${from.name}`,
          paymentMethod: "INTERNAL",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      transactionId = debit.id;
    });
  } catch (error) {
    console.error("Internal transfer request could not be recorded", error);
    return { error: "We couldn't submit this transfer for approval. Please try again." };
  }

  revalidatePath("/dashboard");
  revalidatePath(`/accounts/${fromId}`);
  revalidatePath(`/accounts/${toId}`);
  revalidatePath("/transactions");
  redirect(`/transactions/${transactionId}`);
}

export async function sendMoneyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const fromId = String(formData.get("fromId") ?? "");
  const recipientEmail = String(formData.get("recipientEmail") ?? "").trim().toLowerCase();
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const memo = String(formData.get("memo") ?? "").trim().slice(0, 120) || "Quick Pay";

  if (!amount || amount < 100) return { error: "Enter an amount of at least $1.00" };
  if (amount > 1_000_000) return { error: "Quick Pay is limited to $10,000.00." };
  if (!z.string().email().safeParse(recipientEmail).success) return { error: "Enter a valid recipient email" };

  const from = await db.account.findFirst({ where: { id: fromId, userId } });
  if (!from) return { error: "Account not found" };
  if (from.status !== "ACTIVE") return { error: "This account is not active" };
  if (from.balance < amount) return { error: "Insufficient funds" };

  const recipient = await db.user.findUnique({
    where: { email: recipientEmail },
    include: { accounts: { where: { type: "CHECKING", status: "ACTIVE" }, take: 1 } },
  });
  if (!recipient) return { error: "No First Meridian member was found with that email." };
  if (recipient.id === userId) return { error: "You can't send money to yourself" };
  const toAccount = recipient.accounts[0];
  if (!toAccount) return { error: "Recipient has no active checking account" };

  const reference = randomRef("p2p");
  let transactionId = "";
  try {
    await db.$transaction(async (tx) => {
      const debit = await tx.transaction.create({
        data: {
          accountId: from.id,
          amount: -amount,
          type: "TRANSFER_OUT",
          category: "TRANSFER",
          description: memo,
          counterparty: `${recipient.firstName} ${recipient.lastName}`,
          paymentMethod: "QUICK_PAY",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      await tx.transaction.create({
        data: {
          accountId: toAccount.id,
          amount,
          type: "TRANSFER_IN",
          category: "TRANSFER",
          description: memo,
          counterparty: "First Meridian member transfer",
          paymentMethod: "QUICK_PAY",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      transactionId = debit.id;
    });
  } catch (error) {
    console.error("Quick Pay request could not be recorded", error);
    return { error: "We couldn't submit this payment for approval. Please try again." };
  }

  revalidatePath("/dashboard");
  revalidatePath("/transactions");
  revalidatePath("/receive");
  redirect(`/transactions/${transactionId}`);
}

export async function requestMoneyAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const requesterId = await requireUserId();
  const recipientEmail = String(formData.get("recipientEmail") ?? "").trim().toLowerCase();
  const accountId = String(formData.get("accountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const memo = String(formData.get("memo") ?? "").trim().slice(0, 120) || "Money request";

  if (!z.string().email().safeParse(recipientEmail).success) return { error: "Enter a valid member email." };
  if (!amount || amount < 100) return { error: "Enter an amount of at least $1.00." };
  if (amount > 1_000_000) return { error: "Preview requests are limited to $10,000.00." };

  const [recipient, receiveAccount] = await Promise.all([
    db.user.findUnique({ where: { email: recipientEmail } }),
    db.account.findFirst({ where: { id: accountId, userId: requesterId, status: "ACTIVE" } }),
  ]);
  if (!recipient) return { error: "The other person needs a First Meridian account to receive this request." };
  if (recipient.id === requesterId) return { error: "Choose another member; you can't request money from yourself." };
  if (!receiveAccount) return { error: "Choose an active account you own." };
  const payerAccount = await db.account.findFirst({ where: { userId: recipient.id, status: "ACTIVE" } });
  if (!payerAccount) return { error: "That member does not have an active account to pay this request." };

  await db.moneyRequest.create({
    data: {
      requesterId,
      recipientId: recipient.id,
      recipientEmail: recipient.email,
      accountId: receiveAccount.id,
      amount,
      memo,
      reference: randomRef("req"),
    },
  });
  revalidatePath("/receive");
  redirect("/receive?notice=requested");
}

export async function payMoneyRequestAction(formData: FormData) {
  const payerId = await requireUserId();
  const requestId = String(formData.get("requestId") ?? "");
  const accountId = String(formData.get("accountId") ?? "");
  if (formData.get("confirm") !== "yes") redirect("/receive?notice=confirm");

  const request = await db.moneyRequest.findFirst({
    where: { id: requestId, recipientId: payerId, status: "OPEN" },
    include: { requester: { select: { id: true, firstName: true, lastName: true } }, account: true },
  });
  if (!request) redirect("/receive?notice=unavailable");
  const payerAccount = await db.account.findFirst({ where: { id: accountId, userId: payerId, status: "ACTIVE" } });
  if (!payerAccount) redirect("/receive?notice=account");
  if (request.account.status !== "ACTIVE") redirect("/receive?notice=destination");
  if (payerAccount.balance < request.amount) redirect("/receive?notice=insufficient");

  const reference = request.reference;
  let transactionId = "";
  try {
    await db.$transaction(async (tx) => {
      const claimed = await tx.moneyRequest.updateMany({
        where: { id: request.id, recipientId: payerId, status: "OPEN" },
        data: { status: "PENDING_APPROVAL", paidAt: null },
      });
      if (claimed.count !== 1) throw new Error("REQUEST_UNAVAILABLE");

      const payerEntry = await tx.transaction.create({
        data: {
          accountId: payerAccount.id,
          amount: -request.amount,
          type: "TRANSFER_OUT",
          category: "TRANSFER",
          description: request.memo || "Money request",
          counterparty: `${request.requester.firstName} ${request.requester.lastName}`,
          paymentMethod: "QUICK_PAY",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      await tx.transaction.create({
        data: {
          accountId: request.accountId,
          amount: request.amount,
          type: "TRANSFER_IN",
          category: "TRANSFER",
          description: request.memo || "Money request",
          counterparty: "First Meridian member transfer",
          paymentMethod: "QUICK_PAY",
          status: "PENDING_APPROVAL",
          reference,
        },
      });
      transactionId = payerEntry.id;
    });
  } catch (error) {
    if (error instanceof Error && error.message === "REQUEST_UNAVAILABLE") redirect("/receive?notice=unavailable");
    console.error("Money request payment could not be submitted", error);
    redirect("/receive?notice=error");
  }

  revalidatePath("/dashboard");
  revalidatePath("/transactions");
  revalidatePath("/receive");
  redirect(`/transactions/${transactionId}`);
}

export async function closeMoneyRequestAction(formData: FormData) {
  const userId = await requireUserId();
  const requestId = String(formData.get("requestId") ?? "");
  const side = formData.get("side") === "recipient" ? "recipient" : "requester";
  const where = side === "recipient"
    ? { id: requestId, recipientId: userId, status: "OPEN" }
    : { id: requestId, requesterId: userId, status: "OPEN" };
  const updated = await db.moneyRequest.updateMany({
    where,
    data: { status: side === "recipient" ? "DECLINED" : "CANCELED" },
  });
  revalidatePath("/receive");
  redirect(updated.count === 1
    ? `/receive?notice=${side === "recipient" ? "declined" : "canceled"}`
    : "/receive?notice=unavailable");
}

/* ------------------------------ BILL PAY ------------------------------ */

const billCategorySchema = z.enum(["UTILITIES", "HOUSING", "HEALTH", "OTHER"]);

export async function addBillPayeeAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const parsed = z
    .object({
      name: z.string().trim().min(2, "Enter a company name").max(80),
      category: billCategorySchema,
      accountNumber: z.string().trim().min(3, "Enter the biller account reference").max(80),
    })
    .safeParse({
      name: formData.get("name"),
      category: formData.get("category"),
      accountNumber: formData.get("accountNumber"),
    });
  if (!parsed.success) return { error: parsed.error.errors[0]?.message ?? "Check the biller details" };

  const duplicate = await db.billPayee.findFirst({
    where: { userId, name: { equals: parsed.data.name } },
  });
  if (duplicate) return { error: "That company is already in your biller list" };

  const accountNumber = parsed.data.accountNumber;
  await db.billPayee.create({
    data: {
      userId,
      name: parsed.data.name,
      category: parsed.data.category,
      accountMask: `•••• ${accountNumber.slice(-4)}`,
      encryptedAccountNumber: encryptSensitive(accountNumber),
    },
  });
  revalidatePath("/bill-pay");
  return { success: true, message: `${parsed.data.name} was added to your biller list.` };
}

export async function billPayAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const payeeId = String(formData.get("payeeId") ?? "");
  const accountId = String(formData.get("accountId") ?? "");
  const amount = parseCents(String(formData.get("amount") ?? ""));
  const dateText = String(formData.get("scheduledFor") ?? "");
  const frequency = String(formData.get("frequency") ?? "ONCE");
  const memo = String(formData.get("memo") ?? "").trim().slice(0, 120);

  if (!amount || amount < 100) return { error: "Enter a payment of at least $1.00" };
  if (amount > 1_000_000) return { error: "Bill payments are limited to $10,000.00" };
  if (frequency !== "ONCE" && frequency !== "MONTHLY") return { error: "Choose a valid payment frequency" };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateText)) return { error: "Choose a valid payment date" };
  const scheduledFor = new Date(`${dateText}T12:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (Number.isNaN(scheduledFor.getTime()) || scheduledFor < today) return { error: "Payment date must be today or later" };
  if (scheduledFor.getTime() > Date.now() + 366 * 24 * 60 * 60 * 1000) {
    return { error: "Payment date must be within the next 12 months" };
  }

  const [payee, account] = await Promise.all([
    db.billPayee.findFirst({ where: { id: payeeId, userId } }),
    db.account.findFirst({ where: { id: accountId, userId, status: "ACTIVE" } }),
  ]);
  if (!payee) return { error: "Choose a biller from your saved list" };
  if (!account) return { error: "Choose an active account you own" };
  if (account.balance < amount) return { error: "Insufficient funds for this bill payment" };

  const confirmationNumber = randomRef("bill").toUpperCase();
  let transactionId = "";
  try {
    await db.$transaction(async (tx) => {
      const paymentTransaction = await tx.transaction.create({
        data: {
          accountId: account.id,
          amount: -amount,
          type: "PAYMENT",
          category: payee.category,
          description: `Bill payment — ${payee.name}`,
          counterparty: `${payee.name} · ${payee.accountMask ?? "saved biller"}`,
          paymentMethod: "BILL_PAY",
          status: "PENDING_APPROVAL",
          reference: confirmationNumber,
        },
      });
      transactionId = paymentTransaction.id;
      await tx.billPayment.create({
        data: {
          userId,
          payeeId: payee.id,
          accountId: account.id,
          amount,
          scheduledFor,
          frequency,
          memo: memo || null,
          status: "PENDING_APPROVAL",
          confirmationNumber,
        },
      });
    });
  } catch (error) {
    console.error("Bill payment request could not be recorded", error);
    return { error: "We couldn't submit this payment for approval. Please try again." };
  }

  revalidatePath("/bill-pay");
  revalidatePath("/dashboard");
  revalidatePath("/transactions");
  revalidatePath(`/accounts/${account.id}`);
  redirect(`/transactions/${transactionId}`);
}

/* ------------------------------- CARDS ------------------------------- */

export async function toggleCardAction(formData: FormData) {
  const userId = await requireUserId();
  const cardId = String(formData.get("cardId") ?? "");
  const card = await db.card.findFirst({
    where: { id: cardId, account: { userId } },
    include: { account: true },
  });
  if (!card) return;
  await db.card.update({
    where: { id: card.id },
    data: { status: card.status === "ACTIVE" ? "FROZEN" : "ACTIVE" },
  });
  revalidatePath("/cards");
  revalidatePath("/dashboard");
}

export async function updateCardLimitAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const userId = await requireUserId();
  const cardId = String(formData.get("cardId") ?? "");
  const limit = parseCents(String(formData.get("dailyLimit") ?? ""));
  if (!limit || limit < 100) return { error: "Enter a limit of at least $1.00" };
  const card = await db.card.findFirst({ where: { id: cardId, account: { userId } } });
  if (!card) return { error: "Card not found" };
  await db.card.update({ where: { id: card.id }, data: { dailyLimit: limit } });
  revalidatePath("/cards");
  return { success: true };
}

/* ------------------------------ SETTINGS ------------------------------ */

export async function updateProfileAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (await isSharedPreviewDemoMode()) {
    return { error: "Profile changes are disabled for the shared sample account." };
  }
  const userId = await requireUserId();
  const parsed = z
    .object({
      firstName: z.string().trim().min(1).max(50),
      lastName: z.string().trim().min(1).max(50),
      phone: z.string().trim().max(30).optional().or(z.literal("")),
    })
    .safeParse({
      firstName: formData.get("firstName"),
      lastName: formData.get("lastName"),
      phone: formData.get("phone") ?? "",
    });
  if (!parsed.success) return { error: "Please fill in your name" };

  await db.user.update({
    where: { id: userId },
    data: {
      firstName: parsed.data.firstName,
      lastName: parsed.data.lastName,
      phone: parsed.data.phone || null,
    },
  });
  revalidatePath("/settings");
  revalidatePath("/dashboard");
  return { success: true };
}

export async function changePasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  if (await isSharedPreviewDemoMode()) {
    return { error: "Password changes are disabled for the shared sample account." };
  }
  const userId = await requireUserId();
  const current = String(formData.get("currentPassword") ?? "");
  const next = String(formData.get("newPassword") ?? "");

  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) return { error: "User not found" };
  if (!(await verifyPassword(current, user.passwordHash))) return { error: "Current password is incorrect" };

  const parsed = passwordSchema.safeParse(next);
  if (!parsed.success) return { error: parsed.error.errors[0]?.message ?? "Invalid password" };

  await db.user.update({ where: { id: userId }, data: { passwordHash: await hashPassword(next) } });
  return { success: true };
}
