import "server-only";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const PERIOD_SECONDS = 30;
const CODE_DIGITS = 6;

function encodeBase32(bytes: Buffer): string {
  let buffer = 0;
  let bits = 0;
  let output = "";
  for (const byte of bytes) {
    buffer = (buffer << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(buffer >>> (bits - 5)) & 31];
      bits -= 5;
    }
    buffer &= (1 << bits) - 1;
  }
  if (bits > 0) output += BASE32_ALPHABET[(buffer << (5 - bits)) & 31];
  return output;
}

function decodeBase32(secret: string): Buffer | null {
  let buffer = 0;
  let bits = 0;
  const bytes: number[] = [];
  for (const rawCharacter of secret.toUpperCase().replace(/=+$/g, "")) {
    const value = BASE32_ALPHABET.indexOf(rawCharacter);
    if (value < 0) return null;
    buffer = (buffer << 5) | value;
    bits += 5;
    if (bits >= 8) {
      bytes.push((buffer >>> (bits - 8)) & 255);
      bits -= 8;
    }
    buffer &= (1 << bits) - 1;
  }
  return bytes.length ? Buffer.from(bytes) : null;
}

export function generateTotpSecret(): string {
  return encodeBase32(randomBytes(20));
}

export function totpProvisioningUri(email: string, secret: string): string {
  const label = encodeURIComponent(`First Meridian:${email}`);
  const query = new URLSearchParams({
    secret,
    issuer: "First Meridian",
    algorithm: "SHA1",
    digits: String(CODE_DIGITS),
    period: String(PERIOD_SECONDS),
  });
  return `otpauth://totp/${label}?${query.toString()}`;
}

function codeForStep(secretBytes: Buffer, step: number): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const hmac = createHmac("sha1", secretBytes).update(counter).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binary = ((hmac[offset] & 0x7f) << 24)
    | ((hmac[offset + 1] & 0xff) << 16)
    | ((hmac[offset + 2] & 0xff) << 8)
    | (hmac[offset + 3] & 0xff);
  return String(binary % (10 ** CODE_DIGITS)).padStart(CODE_DIGITS, "0");
}

/** Returns the accepted 30-second counter, allowing a one-step clock skew. */
export function matchingTotpStep(secret: string, code: string, nowMs = Date.now()): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const secretBytes = decodeBase32(secret);
  if (!secretBytes) return null;
  const currentStep = Math.floor(nowMs / (PERIOD_SECONDS * 1000));
  const supplied = Buffer.from(code, "ascii");
  for (const offset of [0, -1, 1]) {
    const step = currentStep + offset;
    if (step < 0) continue;
    const expected = Buffer.from(codeForStep(secretBytes, step), "ascii");
    if (timingSafeEqual(expected, supplied)) return step;
  }
  return null;
}
