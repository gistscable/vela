const longNumberTestPattern = /(?<!\d)(?:\d[ -]?){6,}\d(?!\d)/;
const longNumberReplacePattern = /(?<!\d)(?:\d[ -]?){6,}\d(?!\d)/g;

export function containsLongAccountLikeNumber(value: string): boolean {
  return longNumberTestPattern.test(value);
}

export function lastFourDigits(value: string | null | undefined): string {
  const digits = (value ?? "").replace(/\D/g, "");
  return digits.slice(-4) || "----";
}

function redactLongNumbers(value: string): string {
  return value.replace(longNumberReplacePattern, (match) => {
    const digits = match.replace(/\D/g, "");
    if (/^\d{4}-\d{2}-\d{2}$/.test(match.trim())) return match;
    return `•••• ${digits.slice(-4)}`;
  });
}

export function safeInstitutionName(value: string): string {
  const name = value.trim();
  return containsLongAccountLikeNumber(name) ? "External bank" : redactLongNumbers(name);
}

export function safeExternalNickname(value: string, accountType: string): string {
  const nickname = value.trim();
  if (containsLongAccountLikeNumber(nickname) || /^\d{7,}$/.test(nickname)) {
    return accountType === "SAVINGS" ? "Savings account" : "Checking account";
  }
  return redactLongNumbers(nickname);
}

export function safeCounterparty(value: string | null | undefined): string {
  if (!value) return "";
  const withoutPreviewNote = value.replace(/\bpreview only\b/gi, "");
  const parts = redactLongNumbers(withoutPreviewNote)
    .split(/\s*·\s*/)
    .map((part) => part.trim())
    .filter((part) => part && !/^preview only$/i.test(part));

  const result: string[] = [];
  for (const part of parts) {
    if (/^••••\s*\d{4}$/.test(part) && result.some((item) => item.replace(/\s+/g, " ") === part.replace(/\s+/g, " "))) continue;
    result.push(part);
  }
  return result.join(" · ");
}

export function safeTransactionDescription(value: string): string {
  const description = value.trim().toLowerCase() === "simulated external transfer"
    ? "External transfer"
    : value;
  return redactLongNumbers(description);
}

export function paymentMethodLabel(method: string | null | undefined): string | null {
  if (!method) return null;
  const labels: Record<string, string> = {
    ACH: "ACH",
    WIRE: "Wire",
    BILL_PAY: "Bill Pay",
    INTERNAL: "Internal transfer",
    QUICK_PAY: "Quick Pay",
    MOBILE_DEPOSIT: "Mobile deposit",
  };
  return labels[method] ?? method.replaceAll("_", " ").toLowerCase();
}
