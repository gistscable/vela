/** CORS helpers for cookie-less, simulated actions in the sandboxed Arena preview. */
export function isPreviewApiOriginAllowed(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (origin === "null") return true;
  if (!origin) return false;

  let originHost: string;
  try {
    originHost = new URL(origin).host.toLowerCase();
  } catch {
    return false;
  }

  const requestHosts = [request.headers.get("x-forwarded-host"), request.headers.get("host")]
    .filter((host): host is string => Boolean(host))
    .flatMap((host) => host.split(","))
    .map((host) => host.trim().toLowerCase());

  return requestHosts.includes(originHost);
}

export function previewCorsHeaders(request: Request): Headers {
  const headers = new Headers({
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    Vary: "Origin",
  });
  const origin = request.headers.get("origin");
  if (origin) headers.set("Access-Control-Allow-Origin", origin);
  return headers;
}
