/** Host helper shared by the Edge middleware and server-side preview auth. */
export function isE2bPreviewHost(hostHeader: string | null | undefined): boolean {
  if (!hostHeader) return false;
  const host = hostHeader.split(",")[0].trim().toLowerCase().replace(/:\d+$/, "");
  return host === "e2b.app" || host.endsWith(".e2b.app");
}
