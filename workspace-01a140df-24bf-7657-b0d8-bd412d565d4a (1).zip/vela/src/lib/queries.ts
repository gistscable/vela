import "server-only";
import { db } from "./db";

export type CategoryStat = { category: string; total: number };
export type BalancePoint = { label: string; balance: number };

const CATEGORY_ORDER = [
  "HOUSING",
  "FOOD",
  "TRANSPORT",
  "SHOPPING",
  "ENTERTAINMENT",
  "UTILITIES",
  "HEALTH",
  "TRANSFER",
  "SAVINGS",
  "OTHER",
];

export async function getAccounts(userId: string) {
  return db.account.findMany({
    where: { userId },
    orderBy: { createdAt: "asc" },
    include: {
      cards: true,
      _count: { select: { transactions: true } },
    },
  });
}

export async function getAccountForUser(userId: string, accountId: string) {
  return db.account.findFirst({
    where: { id: accountId, userId },
    include: { cards: true },
  });
}

export async function getRecentTransactions(userId: string, take = 8) {
  return db.transaction.findMany({
    where: { account: { userId } },
    orderBy: { createdAt: "desc" },
    take,
  });
}

export async function getTransactions(
  userId: string,
  opts?: { accountId?: string; category?: string; type?: "CREDIT" | "DEBIT"; search?: string; take?: number }
) {
  const where: Record<string, unknown> = { account: { userId } };
  if (opts?.accountId) where.accountId = opts.accountId;
  if (opts?.category && opts.category !== "ALL") where.category = opts.category;
  if (opts?.type === "CREDIT") where.amount = { gt: 0 };
  if (opts?.type === "DEBIT") where.amount = { lt: 0 };
  if (opts?.search) {
    where.OR = [
      { description: { contains: opts.search } },
      { counterparty: { contains: opts.search } },
    ];
  }
  return db.transaction.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: opts?.take ?? 500,
  });
}

export async function getOverview(userId: string) {
  const accounts = await db.account.findMany({
    where: { userId },
    orderBy: { createdAt: "asc" },
    include: { cards: true },
  });

  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfPrevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

  const monthTx = await db.transaction.findMany({
    where: { account: { userId }, status: "COMPLETED", createdAt: { gte: startOfMonth } },
    select: { amount: true, category: true },
  });
  const prevMonthTx = await db.transaction.findMany({
    where: {
      account: { userId },
      status: "COMPLETED",
      createdAt: { gte: startOfPrevMonth, lt: startOfMonth },
    },
    select: { amount: true },
  });

  const monthIncome = monthTx.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const monthSpending = monthTx.filter((t) => t.amount < 0 && t.category !== "SAVINGS").reduce((s, t) => s + Math.abs(t.amount), 0);
  const prevIncome = prevMonthTx.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const prevSpending = prevMonthTx.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);

  // Spending by category (last 30 days, excludes internal savings transfers)
  const since = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const recent = await db.transaction.findMany({
    where: {
      account: { userId },
      status: "COMPLETED",
      createdAt: { gte: since },
      amount: { lt: 0 },
      category: { notIn: ["SAVINGS", "TRANSFER"] },
    },
    select: { category: true, amount: true },
  });
  const catMap = new Map<string, number>();
  for (const t of recent) {
    catMap.set(t.category, (catMap.get(t.category) ?? 0) + Math.abs(t.amount));
  }
  const spendingByCategory: CategoryStat[] = CATEGORY_ORDER.filter((c) => catMap.has(c)).map((category) => ({
    category,
    total: catMap.get(category)!,
  }));

  // Weekly net cash-flow across last 8 weeks for the sparkline
  const twelveWeeksAgo = new Date(now.getTime() - 8 * 7 * 24 * 60 * 60 * 1000);
  const allTx = await db.transaction.findMany({
    where: { account: { userId }, status: "COMPLETED", createdAt: { gte: twelveWeeksAgo } },
    orderBy: { createdAt: "asc" },
    select: { amount: true, createdAt: true },
  });
  const openingBalance = totalBalance - allTx.reduce((s, t) => s + t.amount, 0);
  const balanceByWeek = new Map<string, number>();
  let running = openingBalance;
  const weeks: { key: string; label: string }[] = [];
  for (let i = 7; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 7 * 24 * 60 * 60 * 1000);
    const key = `${d.getFullYear()}-${d.getMonth()}-${Math.floor(d.getDate() / 7)}`;
    weeks.push({ key, label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) });
  }
  let weekIdx = 0;
  const weekStart = (i: number) => new Date(now.getTime() - (7 - i) * 7 * 24 * 60 * 60 * 1000);
  for (const t of allTx) {
    while (weekIdx < 7 && t.createdAt.getTime() > weekStart(weekIdx + 1).getTime()) {
      balanceByWeek.set(weeks[weekIdx].key, running);
      weekIdx++;
    }
    running += t.amount;
  }
  while (weekIdx < 8) {
    balanceByWeek.set(weeks[weekIdx].key, running);
    weekIdx++;
  }
  const balanceHistory: BalancePoint[] = weeks.map((w, i) => ({
    label: w.label,
    balance: balanceByWeek.get(w.key) ?? (i === 7 ? totalBalance : 0),
  }));
  // fill any zero gaps from sparse data
  for (let i = 1; i < balanceHistory.length; i++) {
    if (balanceHistory[i].balance === 0 && balanceHistory[i - 1].balance !== 0) {
      balanceHistory[i].balance = balanceHistory[i - 1].balance;
    }
  }

  const recentTransactions = await db.transaction.findMany({
    where: { account: { userId } },
    orderBy: { createdAt: "desc" },
    take: 8,
  });

  const savingsAccount = accounts.find((a) => a.type === "SAVINGS");
  const card = accounts.flatMap((a) => a.cards)[0] ?? null;

  return {
    accounts,
    totalBalance,
    monthIncome,
    monthSpending,
    incomeDelta: prevIncome === 0 ? 0 : Math.round(((monthIncome - prevIncome) / prevIncome) * 100),
    spendingDelta: prevSpending === 0 ? 0 : Math.round(((monthSpending - prevSpending) / prevSpending) * 100),
    spendingByCategory,
    balanceHistory,
    recentTransactions,
    savingsAccount,
    card,
  };
}

export async function getStatementsData(userId: string) {
  const accounts = await db.account.findMany({ where: { userId }, orderBy: { createdAt: "asc" } });
  const transactions = await db.transaction.findMany({
    where: { account: { userId } },
    orderBy: { createdAt: "desc" },
    take: 2000,
  });

  // Group into calendar months
  const months = new Map<string, { label: string; transactions: typeof transactions; inflow: number; outflow: number }>();
  for (const t of [...transactions].reverse()) {
    const key = `${t.createdAt.getFullYear()}-${t.createdAt.getMonth()}`;
    if (!months.has(key)) {
      months.set(key, {
        label: t.createdAt.toLocaleDateString("en-US", { month: "long", year: "numeric" }),
        transactions: [],
        inflow: 0,
        outflow: 0,
      });
    }
    const bucket = months.get(key)!;
    bucket.transactions.push(t);
    if (t.status === "COMPLETED") {
      if (t.amount > 0) bucket.inflow += t.amount;
      else bucket.outflow += Math.abs(t.amount);
    }
  }

  const statements = [...months.entries()]
    .map(([key, value]) => ({ key, ...value }))
    .sort((a, b) => (a.key < b.key ? 1 : -1))
    .map((m) => ({ ...m, transactions: m.transactions.sort((x, y) => y.createdAt.getTime() - x.createdAt.getTime()) }));

  return { accounts, statements };
}
