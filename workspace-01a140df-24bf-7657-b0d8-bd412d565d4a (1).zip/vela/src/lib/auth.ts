import "server-only";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { db } from "./db";
import { isE2bPreviewHost } from "./preview";

const COOKIE_NAME = "fmb_session_v2";
const LEGACY_COOKIE_NAME = "fmb_session";
const MFA_CHALLENGE_COOKIE_NAME = "fmb_mfa_pending";
const SESSION_DAYS = 7;
const MFA_CHALLENGE_MINUTES = 10;
export type MfaChallengePurpose = "setup" | "verify";
const SHARED_PREVIEW_EMAIL = "demo@vela.app";

function getSecret() {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET is not set");
  return new TextEncoder().encode(secret);
}

async function useSecureSessionCookie() {
  const requestHeaders = await headers();
  const forwardedProto = requestHeaders.get("x-forwarded-proto")?.split(",")[0]?.trim();
  return process.env.NODE_ENV === "production" || forwardedProto === "https";
}

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export async function createSessionToken(userId: string) {
  return new SignJWT({ sub: userId, mfa: true })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(getSecret());
}

export async function verifySessionToken(token: string): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    return payload.mfa === true && typeof payload.sub === "string" ? payload.sub : null;
  } catch {
    return null;
  }
}

export async function setSessionCookie(userId: string) {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { enrollmentStatus: true, mfaEnabled: true },
  });
  if (!user || user.enrollmentStatus !== "APPROVED" || !user.mfaEnabled) {
    throw new Error("A verified authenticator and approved enrollment are required for a session");
  }
  const token = await createSessionToken(userId);
  const jar = await cookies();
  const secure = await useSecureSessionCookie();
  // Remove older cookies that could shadow the new MFA-verified session.
  jar.delete(LEGACY_COOKIE_NAME);
  jar.set(MFA_CHALLENGE_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: 0,
    expires: new Date(0),
  });

  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    // The app preview can be embedded on a different site. Use a host-only,
    // partitioned cookie there so Chromium can keep the session inside that preview.
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  });
  // Temporary, value-free trace: confirm the server issued the intended cookie policy.
  console.info(`[auth-trace] session-issued secure=${secure} sameSite=${secure ? "none" : "lax"} partitioned=${secure}`);
}

export async function clearSessionCookie() {
  const jar = await cookies();
  const secure = await useSecureSessionCookie();
  // Match the attributes used at login, including the partition key in embedded previews.
  jar.set(COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: 0,
    expires: new Date(0),
  });
  jar.delete(LEGACY_COOKIE_NAME);
  jar.set(MFA_CHALLENGE_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: 0,
    expires: new Date(0),
  });
}

export async function setMfaChallengeCookie(userId: string, purpose: MfaChallengePurpose) {
  const token = await new SignJWT({ purpose })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime(`${MFA_CHALLENGE_MINUTES}m`)
    .sign(getSecret());
  const jar = await cookies();
  const secure = await useSecureSessionCookie();
  jar.delete(LEGACY_COOKIE_NAME);
  jar.set(COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: 0,
    expires: new Date(0),
  });
  jar.set(MFA_CHALLENGE_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: secure ? "none" : "lax",
    secure,
    partitioned: secure,
    path: "/",
    maxAge: MFA_CHALLENGE_MINUTES * 60,
  });
}

export async function getMfaChallengeUser(purpose: MfaChallengePurpose) {
  const token = (await cookies()).get(MFA_CHALLENGE_COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret());
    if (payload.purpose !== purpose || typeof payload.sub !== "string") return null;
    const user = await db.user.findUnique({
      where: { id: payload.sub },
      select: {
        id: true,
        email: true,
        enrollmentStatus: true,
        mfaEnabled: true,
        totpSecretEncrypted: true,
        totpLastUsedStep: true,
        mfaPendingSecretEncrypted: true,
        mfaPendingExpiresAt: true,
        mfaFailedAttempts: true,
        mfaLockedUntil: true,
      },
    });
    if (!user || user.enrollmentStatus !== "APPROVED") return null;
    if (purpose === "setup" && user.mfaEnabled) return null;
    if (purpose === "verify" && !user.mfaEnabled) return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireMfaChallengeUser(purpose: MfaChallengePurpose) {
  const user = await getMfaChallengeUser(purpose);
  if (!user) redirect("/login");
  return user;
}

export async function getSessionUserId(): Promise<string | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const userId = await verifySessionToken(token);
  if (!userId) return null;
  const user = await db.user.findUnique({ where: { id: userId }, select: { enrollmentStatus: true, mfaEnabled: true } });
  return user?.enrollmentStatus === "APPROVED" && user.mfaEnabled ? userId : null;
}

/**
 * True only for the explicitly enabled, token-gated E2B preview host. This mode
 * uses the seeded sample profile because the embedded preview cannot retain cookies.
 */
export async function isSharedPreviewDemoMode(): Promise<boolean> {
  if (process.env.PREVIEW_DEMO_MODE !== "1") return false;
  const requestHeaders = await headers();
  return [requestHeaders.get("x-forwarded-host"), requestHeaders.get("host")].some(isE2bPreviewHost);
}

async function getSharedPreviewDemoUserId(): Promise<string | null> {
  const user = await db.user.findUnique({
    where: { email: SHARED_PREVIEW_EMAIL },
    select: { id: true },
  });
  return user?.id ?? null;
}

/** Returns the authenticated identity, or the shared sample identity in the preview-only mode. */
export async function getEffectiveUserId(): Promise<string | null> {
  if (await isSharedPreviewDemoMode()) return getSharedPreviewDemoUserId();
  return getSessionUserId();
}

/** Fetch the signed-in user or preview sample user, otherwise redirect to login. */
export async function requireUser() {
  const userId = await getEffectiveUserId();
  if (!userId) {
    const token = (await cookies()).get(COOKIE_NAME)?.value;
    const sharedPreview = await isSharedPreviewDemoMode();
    // Temporary, value-free trace; distinguish a missing cookie from a bad token.
    console.warn(`[auth-trace] server redirect reason=${sharedPreview ? "preview_sample_missing" : token ? "invalid_token" : "missing_cookie"}`);
    redirect("/login");
  }
  const user = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      phone: true,
      role: true,
      enrollmentStatus: true,
      createdAt: true,
    },
  });
  if (!user) {
    console.warn("[auth-trace] server redirect reason=session_user_not_found");
    redirect("/login");
  }
  if (user.enrollmentStatus !== "APPROVED") redirect("/login");
  return user;
}

/** Restrict the admin workspace to accounts explicitly promoted by the database owner. */
export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") redirect("/dashboard?notice=admin-only");
  return user;
}
